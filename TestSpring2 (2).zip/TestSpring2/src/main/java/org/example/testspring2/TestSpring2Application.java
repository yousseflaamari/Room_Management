package org.example.testspring2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication
@EntityScan("org.example.testspring2.model")
@EnableJpaRepositories("org.example.testspring2.repository")
public class TestSpring2Application {

    public static void main(String[] args) {
        SpringApplication.run(TestSpring2Application.class, args);
    }

}
